﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Banking_Application_for_United_Online.Models;
using Banking_Application_for_United_Online.DataLayer;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Banking_Application_for_United_Online.Controllers;

public class BankTransferController : Controller
{
    [HttpGet]
    public IActionResult BankTransfer()
    {
        try
        {
            List<Accounts> AccountsList = AccountsDAL.AccountList();
            //ViewBag["AccountList"] = AccountsList;
            ViewBag.AccountList = new SelectList(AccountsList, "AccountNumber", "AccountName");

            return View();
        }
        catch (Exception ex)
        {
            TempData["errorMessage"] = ex.Message.ToString();
            return View();
        }
    }



    [HttpPost]
    public IActionResult BankTransfer(Accounts FromAcc, Accounts ToAcc,Decimal AmountToTransfer)
    {
        try
        {
            int FromAccount = int.Parse(Request.Form["FromAccount"]);


            int ToAccount = int.Parse(Request.Form["ToAccount"]);

            Decimal Amount = Decimal.Parse(Request.Form["Amount"]);
            if (!ModelState.IsValid)
            {
                TempData["errorMessage"] = "Model Data is InValid..!";
            }
            BankTransferDAL _transferFund = new BankTransferDAL();
            bool result = _transferFund.TransferFund(FromAccount, ToAccount, AmountToTransfer);

            if (!result)
            {
                TempData["errorMessage"] = "Unable to Save the Data..!";
                return View();
            }
            TempData["successMessage"] = "New Account Created Sucessfully..!";

            return RedirectToAction("BankTransfer");
        }
        catch (Exception ex)
        {
            TempData["errorMessage"] = ex.Message.ToString();
            return View();
        }
    }
}

