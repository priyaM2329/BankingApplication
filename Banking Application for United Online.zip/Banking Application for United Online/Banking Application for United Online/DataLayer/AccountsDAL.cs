﻿using System;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using Banking_Application_for_United_Online.Models;

namespace Banking_Application_for_United_Online.DataLayer
{
	public class AccountsDAL
	{
		public string con = "";

		public AccountsDAL()
		{
			var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();

			con = builder.GetSection("ConnectionStrings:DefaultConnectionString").Value;
		}

		public List<Accounts> GetAllAccounts()
		{
			List<Accounts> ListofAccounts = new List<Accounts>();
			using (SqlConnection cn = new SqlConnection("Server=localhost;Database=BankingApp;User Id=SA;Password=Password123;Trusted_Connection=True;integrated security=false;TrustServerCertificate=True;"))
			//using (SqlConnection cn = new SqlConnection(con))
			{
				using (SqlCommand cmd = new SqlCommand("GetAllAccounts", cn))
				{
					cn.Open();
					bool flag = false;

                    if (cn.State == ConnectionState.Open)
						flag = true;

                    SqlDataReader reader = cmd.ExecuteReader();
					string accname = "", Balance = "";
					while (reader.Read())
					{
						accname = reader["AccountName"].ToString();
						Balance = reader["Balance"].ToString();

                        ListofAccounts.Add(new Accounts()
						{
							AccountName = reader["AccountName"].ToString(),
							Balance = decimal.Parse((reader["Balance"]).ToString()),
						});
					}


				}
				
			}
            return ListofAccounts;
        }

		public bool CreateAccount(Accounts model)
		{
			 int flag;
                using (SqlConnection cn = new SqlConnection("Server=localhost;Database=BankingApp;User Id=SA;Password=Password123;Trusted_Connection=True;integrated security=false;TrustServerCertificate=True;"))
                //using (SqlConnection cn = new SqlConnection(con))
                {
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "CreateNewAccount";
                    cmd.Parameters.AddWithValue("@AccountName", model.AccountName);
                    cmd.Parameters.AddWithValue("@Balance", model.Balance);
                    cn.Open();
                    flag = cmd.ExecuteNonQuery();

                }

                return flag > 0 ? true : false;
            
        }


        public static List<Accounts> AccountList()
        {
            string constr = "Server=localhost;Database=BankingApp;User Id=SA;Password=Password123;Trusted_Connection=True;integrated security=false;TrustServerCertificate=True;";
            List<Accounts> AccNames= new List<Accounts>();
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "SELECT AccountName, AccountNumber FROM Accounts";
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            AccNames.Add(new Accounts
                            {
                                AccountName = sdr["AccountName"].ToString(),
                                AccountNumber = Convert.ToInt32(sdr["AccountNumber"])
                            });
                        }
                    }
                    con.Close();
                }
            }

            return AccNames;
        }
    }



}
 
