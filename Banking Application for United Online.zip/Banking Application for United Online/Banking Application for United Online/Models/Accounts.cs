﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace Banking_Application_for_United_Online.Models
{
    public class Accounts
    {
        [Key]
        [Required]
        public string AccountName { get; set; }
        [Required]
        public decimal Balance { get; set; }
        public int AccountNumber { get; set; }

        public int SelectedItemValue { set; get; }
    }

    
}

