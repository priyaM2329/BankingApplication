﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Banking_Application_for_United_Online.Models;
using Banking_Application_for_United_Online.DataLayer;

namespace Banking_Application_for_United_Online.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    public IActionResult Accounts()
    {
        AccountsDAL _accountsDAL = new AccountsDAL();

        List<Accounts> AccountList = new List<Accounts>();

        AccountList = _accountsDAL.GetAllAccounts();

        return View(AccountList);
    }
}

