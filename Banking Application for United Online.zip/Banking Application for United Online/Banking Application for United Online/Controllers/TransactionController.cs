﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Banking_Application_for_United_Online.Models;
using Banking_Application_for_United_Online.DataLayer;

namespace Banking_Application_for_United_Online.Controllers;

public class TransactionController : Controller
{
    [HttpGet]
    public IActionResult TransactionDetails()
    {
        TransactionDAL _transDAL = new TransactionDAL();

        List<Transactions> TransactionList = new List<Transactions>();

        TransactionList = _transDAL.GetAllTansactions();

        return View(TransactionList);
    }

    
}

