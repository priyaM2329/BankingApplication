﻿using System;
using Banking_Application_for_United_Online.Models;
using System.Data;
using System.Data.SqlClient;

namespace Banking_Application_for_United_Online.DataLayer
{
	public class TransactionDAL
	{
        public string con = "";

        public TransactionDAL()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();

            con = builder.GetSection("ConnectionStrings:DefaultConnectionString").Value;
        }



        public List<Transactions> GetAllTansactions()
        {
            List<Transactions> TransList = new List<Transactions>();
            using (SqlConnection cn = new SqlConnection("Server=localhost;Database=BankingApp;User Id=SA;Password=Password123;Trusted_Connection=True;integrated security=false;TrustServerCertificate=True;"))
            //using (SqlConnection cn = new SqlConnection(con))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from Transactions", cn))
                {
                    cn.Open();
                    

                    SqlDataReader reader = cmd.ExecuteReader();
                    // string accname = "", Balance = "";
                    while (reader.Read())
                    {
                        TransList.Add(new Transactions()
                        {
                            FromAccountName = reader["FromAccountName"].ToString(),
                            ToAccountName = reader["ToAccountName"].ToString(),
                            TransTime = DateTime.Parse(reader["TransactionsTime"].ToString()),
                            Amount = Convert.ToDecimal(reader["AmountDebited"]),
                            FromBalance = Convert.ToDecimal(reader["FromAccBalance"]),
                            ToBalance = Convert.ToDecimal(reader["ToAccBalance"])
                            
                        });
                    }


                }

            }
            return TransList;
        }
    }
}

