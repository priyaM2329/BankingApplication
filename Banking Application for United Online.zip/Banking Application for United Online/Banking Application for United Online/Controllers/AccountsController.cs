﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Banking_Application_for_United_Online.Models;
using Banking_Application_for_United_Online.DataLayer;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Banking_Application_for_United_Online.Controllers;

public class AccountsController : Controller
{
    [HttpGet]
    public  IActionResult CreateNewAccount()
    {

        return View();
    }


    [HttpPost]
    public IActionResult CreateNewAccount(Accounts NewAcc)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                TempData["errorMessage"] = "Model Data is InValid..!";
            }
            AccountsDAL _accountsDAL = new AccountsDAL();
            bool result = _accountsDAL.CreateAccount(NewAcc);

            if (!result)
            {
                TempData["errorMessage"] = "Unable to Save the Data..!";
                return View();
            }
            TempData["successMessage"] = "New Account Created Sucessfully..!";

            return RedirectToAction("CreateNewAccount");
        }
        catch(Exception ex)
        {
            TempData["errorMessage"] = ex.Message.ToString();
            return View();
        }
    }


    [HttpGet]
    public IActionResult EditAccount()
    {
        try
        {
            List<Accounts> AccountsList = AccountsDAL.AccountList();
            //ViewBag["AccountList"] = AccountsList;
            ViewBag.AccountList = new SelectList(AccountsList, "AccountNumber", "AccountName");

            return View();
        }
        catch (Exception ex)
        {
            TempData["errorMessage"] = ex.Message.ToString();
            return View();
        }
    }

}

