﻿using System;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using Banking_Application_for_United_Online.Models;

namespace Banking_Application_for_United_Online.DataLayer
{
    public class BankTransferDAL
    {
        public string con = "";

        public BankTransferDAL()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();

            con = builder.GetSection("ConnectionStrings:DefaultConnectionString").Value;
        }

        
        public bool TransferFund(int FromAccount, int ToAccount, Decimal AmountToTransfer)
        {
            int flag;
            using (SqlConnection cn = new SqlConnection("Server=localhost;Database=BankingApp;User Id=SA;Password=Password123;Trusted_Connection=True;integrated security=false;TrustServerCertificate=True;"))
            //using (SqlConnection cn = new SqlConnection(con))
            {
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "TransferFund";
                cmd.Parameters.AddWithValue("@ToAccountNumber", ToAccount);
                cmd.Parameters.AddWithValue("@FromAccountNumber", FromAccount);
                cmd.Parameters.Add("@result", SqlDbType.Int);
                cmd.Parameters["@result"].Direction = ParameterDirection.Output;
                cn.Open();
                flag = cmd.ExecuteNonQuery();

            }

            return flag > 0 ? true : false;

        }


        
    }



}

