﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace Banking_Application_for_United_Online.Models
{
    public class Transactions
    {
        
        public string FromAccountName { get; set; }
        public string ToAccountName { get; set; }
        public DateTime TransTime { get; set; }
        public decimal Amount { get; set; }
        public decimal FromBalance { get; set; }
        public decimal ToBalance { get; set; }

    }


}
